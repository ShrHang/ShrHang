package io.github.shrhang.create_food_filling.mixin;

import io.github.shrhang.create_food_filling.Config;
import io.github.shrhang.create_food_filling.api.event.AnimalFeedingEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.NeoForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static io.github.shrhang.create_food_filling.content.util.ApplyEffectUtil.preFilter;

@Mixin(Animal.class)
public abstract class AnimalMixin {
    @Inject(method = "usePlayerItem", at = @At("TAIL"))
    private void create_food_filling$onAnimalFed(Player player, InteractionHand hand, ItemStack itemStack, CallbackInfo ci) {
        if (!Config.SERVER.enableFeedAnimalFoodEffects.get()) return;
        Animal animal = (Animal) (Object) this;
        if (!preFilter(itemStack, animal)) return;
        NeoForge.EVENT_BUS.post(new AnimalFeedingEvent(animal, player, hand, itemStack));
    }
}
